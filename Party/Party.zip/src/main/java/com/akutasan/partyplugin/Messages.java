//package com.akutasan.partyplugin;
//
//public class Messages {
//    public static String PREFIX;
//    public static String IS_NOT_IN_PARTY;
//    public static String NOT_ONLINE;
//    public static String INVITE_PLAYER_IN_PARTY;
//    public static String INVITE_PLAYER_TO_PARTY;
//    public static String ACCEPT_PARTY_INVATION;
//    public static String DENY_PARTY_INVATION;
//    public static String DELETE_PARTY_NO_USERS;
//    public static String PARTY_DELETED;
//    public static String PARTY_JOIN;
//    public static String PARTY_LEAVE;
//    public static String HAS_INVENTATION;
//    public static String KICK_PLAYER_FROM_PARTY;
//    public static String CAN_GET_INVATIONS;
//    public static String CANNOT_GET_INVENTIONS;
//    public static String INVITE_BUT_CANNOT_BECOUSE_TOGGLED;
//    public static String IS_IN_ANOTHER_PARTY;
//
//    public static void load()
//    {
//        PREFIX = "§c§lReqiuem §7• ";
//        IS_IN_ANOTHER_PARTY = "";
//        INVITE_BUT_CANNOT_BECOUSE_TOGGLED = "§cDer Spieler %PLAYER% nimmt keine Anfragen an";
//        CANNOT_GET_INVENTIONS = "§aDu kannst nun keine Anfragen mehr erhalten";
//        CAN_GET_INVATIONS = "§aDu kannst nun Anfragen erhalten";
//        KICK_PLAYER_FROM_PARTY = "§cDu wurdest von %PLAYER% aus der Party gekickt";
//        HAS_INVENTATION = "";
//        PARTY_LEAVE = "§6%PLAYER% §ehat die Party verlassen";
//        IS_NOT_IN_PARTY = "§cDu bist in keiner Party";
//        INVITE_PLAYER_IN_PARTY = "";
//        INVITE_PLAYER_TO_PARTY = "";
//        ACCEPT_PARTY_INVATION = "";
//        DENY_PARTY_INVATION = "";
//        DELETE_PARTY_NO_USERS = "§cDie Party wird wegen zu wenig Mitgliedern aufgelöst";
//        PARTY_DELETED = "§cDie Party wurde aufgelöst";
//        PARTY_JOIN = "§6%PLAYER% §e ist der Party beigetreten";
//    }
//}
