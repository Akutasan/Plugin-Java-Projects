package com.akutasan.partyplugin.commands;

import com.akutasan.partyplugin.Main;
import com.akutasan.partyplugin.manager.PartyManager;
import com.akutasan.partyplugin.manager.PlayerParty;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.plugin.Command;

public class PartyChat extends Command {
    public PartyChat()
    {
        super("p");
    }

    public void execute(CommandSender sender, String[] args)
    {
        if (args.length == 0)
        {
            sender.sendMessage(new TextComponent(Main.partyprefix + "§c/p <Nachricht>"));
            return;
        }
        ProxiedPlayer p = (ProxiedPlayer)sender;
        if (PartyManager.getParty(p) == null)
        {
            p.sendMessage(new TextComponent(Main.partyprefix + "§cDu bist in §ckeiner §cParty."));
            return;
        }
        PlayerParty party = PartyManager.getParty(p);
        String msg = "";
        int j = args.length;
        int i = 0;
        while (i < j) {
            String s = args[i];
            msg = msg + "§7 " + s;
            i++;
        }
        for (ProxiedPlayer members : party.getPlayers()) {
            members.sendMessage(new TextComponent("§d§lParty §8• §6" + p.getName() + " §8» §7" + msg));
        }
        party.getLeader().sendMessage(new TextComponent("§d§lParty §8• §6" + p.getName() + " §8» §7" + msg));
    }
}

//&d&lParty &8• &6NAME &8» &7MESSAGE
