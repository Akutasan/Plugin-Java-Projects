package com.akutasan.partyplugin.commands;


import com.akutasan.partyplugin.Main;
import com.akutasan.partyplugin.manager.PartyManager;
import com.akutasan.partyplugin.manager.PlayerParty;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;

public class PartyList
        extends SubCommand
{
    public PartyList() {
        super("", "", "list");
    }

    public void onCommand(ProxiedPlayer p, String[] args)
    {
        if (PartyManager.getParty(p) == null)
        {
            p.sendMessage(new TextComponent(Main.partyprefix + "§cDu bist in §ckeiner §cParty!"));
            return;
        }
        PlayerParty party = PartyManager.getParty(p);
        StringBuilder user = new StringBuilder("§7Spieler§7: §e");
        int psize = party.getPlayers().size() + 1;
        if (!party.getPlayers().isEmpty())
        {
            for (ProxiedPlayer pp : party.getPlayers()) {
                user.append(pp.getName()).append("§7, §7");
            }
            new StringBuilder(user.substring(1, user.lastIndexOf("§7, §7")));
        }
        else {
            user.append(" §8Keine");
        }
        p.sendMessage(new TextComponent("§8§m---------§7[§5Deine Party §6(" + psize + ")§7]§8§m---------"));
        p.sendMessage(new TextComponent("§dParty Leader: §6" + party.getLeader().getName()));
        for (ProxiedPlayer pp : party.getPlayers()) {
            p.sendMessage(new TextComponent("§dParty Member: §6" + party.getPlayers()));
        }
        p.sendMessage(new TextComponent("§dOnline auf §a" + p.getServer().getInfo().getName()));
        p.sendMessage(new TextComponent("§8§m-----§8§m-----§8§m-----§8§m----§8§m-----§8§m----§8§m----"));
    }
}

/*
 public void onCommand(ProxiedPlayer p, String[] args)
    {
        if (PartyManager.getParty(p) == null)
        {
            p.sendMessage(new TextComponent("§cDu bist in §ckeiner §cParty!"));
            return;
        }
        PlayerParty party = PartyManager.getParty(p);
        String leader = "§4Leader§7: §6" + party.getLeader();
        String user = "§7Spieler§7: §e";
        int psize = party.getPlayers().size() + 1;
        if (!party.getPlayers().isEmpty())
        {
            for (ProxiedPlayer pp : party.getPlayers()) {
                user = user + pp.getName() + "§7, §7";
            }
            user = user.substring(1, user.lastIndexOf("§7, §7"));
        }
        else {
            user = user + " §8Keine";
        }
        p.sendMessage(new TextComponent("§8§m---------§7[§5Deine Party §6(" + psize + ")§7]§8§m---------"));
        p.sendMessage(new TextComponent("§dParty Leader: §6" + party.getLeader().getName()));
        for (ProxiedPlayer pp : party.getPlayers()) {
            pp.sendMessage(new TextComponent("§dParty Member: §6" + party.getPlayers()));
        }
        p.sendMessage(new TextComponent("§dOnline auf §a" + p.getServer().getInfo().getName()));
        p.sendMessage(new TextComponent("§8§m-----§8§m-----§8§m-----§8§m----§8§m-----§8§m----§8§m----"));
    }
 */
