//package com.akutasan.partyplugin.commands;
//
//import com.akutasan.partyplugin.Main;
//import com.akutasan.partyplugin.manager.PartyManager;
//import com.akutasan.partyplugin.manager.PlayerParty;
//import net.md_5.bungee.api.chat.TextComponent;
//import net.md_5.bungee.api.connection.ProxiedPlayer;
//
//public class PartyDisband extends SubCommand{
//    public PartyDisband() {
//        super("","","disband");
//    }
//
//    @Override
//    public void onCommand(ProxiedPlayer p, String[] args) {
//        PlayerParty party = PartyManager.getParty(p);
//        if (PartyManager.getParty(p) == null) {
//            p.sendMessage(new TextComponent(String.valueOf(Main.partyprefix) + "§cDu bist in keiner Party."));
//        }
//        else if (party.isLeader(p)) {
//            for (ProxiedPlayer pp : party.getPlayers()) {
//                pp.sendMessage(new TextComponent(Main.partyprefix + "§cDer §cParty Besitzer §chat §cdie §cParty §caufgelöst"));
//                party.removePlayer(p);
//                party.removePlayer(pp);
//            }
//            p.sendMessage(new TextComponent(Main.partyprefix + "§cDu §chast §cdie §cParty §caufgelöst!"));
//            party.removePlayer(p);
////            PartyManager.deleteParty(p);
//        } else {
//            p.sendMessage(new TextComponent(Main.partyprefix + "§cDu §cbist §cnicht §cder §cParty §cBesitzer!"));
//        }
//    }
//}
