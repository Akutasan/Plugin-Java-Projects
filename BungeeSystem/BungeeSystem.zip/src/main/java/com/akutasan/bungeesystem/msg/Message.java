package com.akutasan.bungeesystem.msg;

import com.akutasan.bungeesystem.Main;
import com.google.common.collect.ImmutableSet;
import de.dytanic.cloudnet.api.CloudAPI;
import de.dytanic.cloudnet.lib.player.OfflinePlayer;
import de.dytanic.cloudnet.lib.player.permission.GroupEntityData;
import net.md_5.bungee.BungeeCord;
import net.md_5.bungee.api.ChatColor;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.plugin.Command;

import java.util.*;


public class Message extends Command {
    public static HashMap<String, String> reply = new HashMap();


    public Message() {
        super("msg","","message","whisper","tell","w");
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        String prefix = Main.getInstance().prefix;
        if (sender instanceof ProxiedPlayer) {
                ProxiedPlayer player = (ProxiedPlayer) sender;

                if (args.length >= 2) {
                    ProxiedPlayer player2 = Main.getInstance().getProxy().getPlayer(args[0]);
                    if (player2 == null) {
                        player.sendMessage(new TextComponent(prefix + "§cDieser Spieler ist nicht §cOnline!"));
                        return;
                    }

                    if (player.getName().equals(player2.getName())) {
                        player.sendMessage(new TextComponent(prefix + "§cDu kannst dir nicht §cselbst §cNachrichten §cschreiben!"));
                        return;
                    }

                    if (ToggleMsg.tmsg.contains(player2)) {
                        player.sendMessage(new TextComponent(prefix + getRankCol(player2)+player2.getName()+" §chat seine Nachrichten §cdeaktiviert!"));
                        return;
                    }

                    if (ToggleMsg.tmsg.contains(player)){
                        player.sendMessage(new TextComponent(prefix + " §cDu kannst keine Nachrichten versenden!"));
                        return;
                    }

                    StringBuilder mes = new StringBuilder();

                    for (int i = 1; i < args.length; ++i) {
                        mes.append(ChatColor.YELLOW).append(args[i]).append(" ");
                    }

//                    String tusv = player.getServer().getInfo().getName();
//                    String susv = player2.getServer().getInfo().getName();
                    String senderFormat = "§8[§d§lMSG§8] §7Du §8➛ "+getRankCol(player2)+player2.getName()+" §8» "+ ChatColor.YELLOW+mes.toString();
                    String receiverFormat = "§8[§d§lMSG§8] "+getRankCol(player)+player.getName()+" §8➛ §7Dir §8» "+ChatColor.YELLOW+mes.toString();
                    player.sendMessage(new TextComponent(senderFormat));
                    player2.sendMessage(new TextComponent(receiverFormat));

                    for (ProxiedPlayer staffs : Main.getInstance().getProxy().getPlayers()) {
                        if (SocialSpy.sp.contains(staffs)) {
                            if (staffs.equals(player))return;
                            String format = "§8[§5MSG Spy§8] "+getRankCol(player)+player.getName()+" §7zu "+getRankCol(player2)+player2.getName()+" §8» "+ChatColor.YELLOW+mes.toString();
                            staffs.sendMessage(new TextComponent(format));
                        }
                    }

                    if (ReplyCommand.replyhash.containsKey(player) || ReplyCommand.replyhash.containsKey(player2)) {
                        ReplyCommand.replyhash.remove(player);
                        ReplyCommand.replyhash.remove(player2);
                        ReplyCommand.replyhash.put(player, player2);
                        ReplyCommand.replyhash.put(player2, player);
                    }

                    ReplyCommand.replyhash.put(player, player2);
                    ReplyCommand.replyhash.put(player2, player);
                } else {
                    player.sendMessage(new TextComponent(prefix + "§e/msg <Spieler> <Nachricht>"));
                    player.sendMessage(new TextComponent(prefix + "§e/r <Nachricht>"));
                    player.sendMessage(new TextComponent(prefix + "§e/msgtoggle"));
                    if (player.hasPermission("reqiuem.admin")) {
                        player.sendMessage(new TextComponent(prefix + "§e/spy"));
                    }
                }
        } else {
            sender.sendMessage(new TextComponent(prefix + "§cDu musst ein Spieler §csein §cum §cdies §czu tun!"));
        }
    }

    public static String getRankName(ProxiedPlayer player){
        UUID uniqueId = UUID.fromString(player.getUniqueId().toString());
        OfflinePlayer offlinePlayer = CloudAPI.getInstance().getOfflinePlayer(uniqueId);
        StringBuilder stringBuilder = new StringBuilder();
        for (GroupEntityData groupEntityData : offlinePlayer.getPermissionEntity().getGroups()) {
            stringBuilder.append(groupEntityData.getGroup());
        }
        return stringBuilder.substring(0);
    }

    private static String getRankCol(ProxiedPlayer player) {
        switch (getRankName(player)) {
            case "Owner":
                return "§4";
            case "Admin":
            case "SrDeveloper":
            case "SrModerator":
            case "SrBuilder":
                return "§c";
            case "Developer":
                return "§b";
            case "Moderator":
                return "§9";
            case "Supporter":
                return "§3";
            case "Builder":
                return "§e";
            case "Social":
                return "§5";
            case "MVP":
                return "§d";
            case "VIP":
                return "§a";
            case "Premium":
                return "§6";
            default:
                return "§7";
        }
    }
}

//
//                if (player.hasPermission("Score.Owner")) {
//                return "§4";
//                } else if (player.hasPermission("Score.Admin")) {
//                return "§c";
//                } else if (player.hasPermission("Score.SrDeveloper")) {
//                return "§c";
//                } else if (player.hasPermission("Score.Developer")) {
//                return "§b";
//                } else if (player.hasPermission("Score.SrModerator")) {
//                return "§c";
//                } else if (player.hasPermission("Score.Moderator")) {
//                return "§9";
//                } else if (player.hasPermission("Score.SrBuilder")) {
//                return "§c";
//                } else if (player.hasPermission("Score.Supporter")) {
//                return "§3";
//                } else if (player.hasPermission("Score.Builder")) {
//                return "§e";
//                }  else if (player.hasPermission("Score.YouTuber")) {
//                return "§5";
//                } else if (player.hasPermission("Score.MVP")) {
//                return "§d";
//                } else if (player.hasPermission("Score.VIP")) {
//                return "§a";
//                } else if (player.hasPermission("Score.Premium")) {
//                return "§6";
//                } else if (player.hasPermission("Score.Spieler")){
//                return "§7";
//                } else {
//                return "§7";
//                }
//&8[&d&lMSG&8] &7Du &8➛ &2Name