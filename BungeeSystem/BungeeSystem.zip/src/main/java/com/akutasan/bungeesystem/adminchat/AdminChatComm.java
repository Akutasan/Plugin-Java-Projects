package com.akutasan.bungeesystem.adminchat;

import com.akutasan.bungeesystem.Main;
import de.dytanic.cloudnet.api.CloudAPI;
import de.dytanic.cloudnet.lib.player.OfflinePlayer;
import de.dytanic.cloudnet.lib.player.permission.GroupEntityData;
import net.md_5.bungee.api.ChatColor;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.plugin.Command;

import java.util.UUID;

public class AdminChatComm extends Command {
    private Main plugin;

    public AdminChatComm(Main plugin){
        super("ac","reqiuem.admin", "adminchat");
        this.plugin = plugin;
    }

    @Override
    public void execute(CommandSender sender, String[] args) {
        ProxiedPlayer p = (ProxiedPlayer) sender;
        StringBuilder sb = new StringBuilder();
        for (String arg : args) {
            sb.append(ChatColor.GRAY).append(arg).append(" ");
        }
        if (sb.toString().equalsIgnoreCase("")||sb.toString().equalsIgnoreCase(" ")){
            return;
        }
        this.plugin.sendAdmin(getRank(p),p.getName()+" §8» §7"+sb.toString());
    }

    public static String getRankName(ProxiedPlayer player){
        UUID uniqueId = UUID.fromString(player.getUniqueId().toString());
        OfflinePlayer offlinePlayer = CloudAPI.getInstance().getOfflinePlayer(uniqueId);
        StringBuilder stringBuilder = new StringBuilder();
        for (GroupEntityData groupEntityData : offlinePlayer.getPermissionEntity().getGroups()) {
            stringBuilder.append(groupEntityData.getGroup());
        }
        return stringBuilder.substring(0);
    }

    private static String getRank(ProxiedPlayer player) {
        switch (getRankName(player)) {
            case "Owner":
                return "§4Owner §r§7• §4";
            case "Admin":
                return "§cAdmin §r§7• §c";
            case "SrDeveloper":
                return "§cSrDev §r§7• §c";
            case "SrModerator":
                return "§cSrMod §r§7• §c";
            case "SrBuilder":
                return "§cSrBuilder §r§7• §c";
            default:
                return "§7Tester §r§7• §7";
        }
    }
}
